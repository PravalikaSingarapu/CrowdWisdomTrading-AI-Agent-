#!/usr/bin/env python3
"""
CrowdWisdomTrading AI Agent
A CrewAI-based system for finding US financial market creators on X/Twitter.
"""

import os
import json
import time
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional, Union
import logging

from crewai import Agent, Task, Crew
from crewai.flow import Flow, listen, start
from pydantic import BaseModel, Field
import tweepy
import litellm
from dotenv import load_dotenv
from typing import Optional

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('crowdwisdom_trading.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Data models
class TwitterUser(BaseModel):
    username: str
    user_id: str
    followers_count: int
    posts_per_week: float
    profile_url: str
    bio: str = ""
    verified: bool = False
    recent_tweets_count: int = 0

class SearchStats(BaseModel):
    total_processing_time: float
    total_users_found: int
    total_users_filtered: int
    search_keywords_used: List[str]
    timestamp: str

class SearchResults(BaseModel):
    qualified_users: List[TwitterUser]
    statistics: SearchStats

# Twitter API Configuration
class TwitterAPIClient:
    def __init__(self):
        bearer_token = os.getenv("TWITTER_BEARER_TOKEN")
        if not bearer_token:
            raise ValueError("TWITTER_BEARER_TOKEN environment variable not set")
        
        self.client = tweepy.Client(bearer_token=bearer_token)
        logger.info("Twitter API client initialized")
    
    def search_tweets_by_keywords(self, keywords: List[str], max_results: int = 100) -> List[Dict]:
        """Search for recent tweets using financial market keywords"""
        all_tweets = []
        
        for keyword in keywords:
            try:
                query = f"{keyword} -is:retweet lang:en"
                tweets = self.client.search_recent_tweets(
                    query=query,
                    max_results=max_results,
                    tweet_fields=['author_id', 'created_at', 'public_metrics'],
                    user_fields=['followers_count', 'public_metrics', 'verified']
                )
                
                if tweets and hasattr(tweets, 'data') and tweets.data:
                    for tweet in tweets.data:
                        all_tweets.append({
                            'id': str(tweet.id),
                            'text': tweet.text,
                            'author_id': str(tweet.author_id),
                            'created_at': str(tweet.created_at),
                            'public_metrics': tweet.public_metrics
                        })
                    logger.info(f"Found {len(tweets.data)} tweets for keyword: {keyword}")
                
                # Rate limiting - Twitter allows 300 requests per 15 minutes
                time.sleep(1)
                
            except Exception as e:
                logger.error(f"Error searching tweets for keyword '{keyword}': {str(e)}")
                continue
        
        return all_tweets
    
    def get_user_details(self, user_ids: List[str]) -> List[Dict]:
        """Get detailed user information for a list of user IDs"""
        users_data = []
        
        # Process in batches of 100 (Twitter API limit)
        batch_size = 100
        for i in range(0, len(user_ids), batch_size):
            batch_ids = user_ids[i:i + batch_size]
            
            try:
                users = self.client.get_users(
                    ids=batch_ids,
                    user_fields=['followers_count', 'public_metrics', 'verified', 'description', 'username']
                )
                
                if users and hasattr(users, 'data') and users.data:
                    for user in users.data:
                        users_data.append({
                            'id': str(user.id),
                            'username': user.username,
                            'followers_count': user.followers_count,
                            'verified': user.verified,
                            'description': user.description or "",
                            'public_metrics': user.public_metrics
                        })
                
                # Rate limiting
                time.sleep(1)
                
            except Exception as e:
                logger.error(f"Error getting user details for batch: {str(e)}")
                continue
        
        return users_data
    
    def get_user_recent_tweets_count(self, user_id: str, days: int = 14) -> int:
        """Count user's tweets in the last N days"""
        try:
            end_time = datetime.utcnow()
            start_time = end_time - timedelta(days=days)
            
            tweets = self.client.get_users_tweets(
                id=user_id,
                start_time=start_time,
                end_time=end_time,
                max_results=100,
                exclude=['retweets', 'replies']
            )
            
            if tweets and hasattr(tweets, 'data') and tweets.data:
                return len(tweets.data)
            return 0
            
        except Exception as e:
            logger.error(f"Error getting recent tweets count for user {user_id}: {str(e)}")
            return 0

# Initialize Twitter client (with error handling)
try:
    twitter_client = TwitterAPIClient()
except ValueError as e:
    logger.warning(f"Twitter API not configured: {str(e)}. Running in demo mode.")
    twitter_client = None

# CrewAI Tools Functions
def generate_financial_keywords() -> List[str]:
    """Generate relevant keywords for searching US financial market content"""
    base_keywords = [
        "US stock market", "S&P 500", "NASDAQ", "Dow Jones", "NYSE",
        "Federal Reserve", "Fed rate", "interest rates", "bond yields",
        "Wall Street", "stock picks", "market analysis", "earnings report",
        "economic indicators", "inflation data", "GDP growth", "unemployment rate",
        "tech stocks", "banking sector", "energy sector", "healthcare stocks",
        "market volatility", "bull market", "bear market", "market crash",
        "IPO", "stock split", "dividend yield", "P/E ratio", "market cap"
    ]
    
    # Use LiteLLM to generate additional contextual keywords
    try:
        prompt = """Generate 10 additional specific keywords or phrases that financial market creators 
        would commonly use when posting about US financial markets on social media. 
        Focus on trending topics, market terminology, and current events.
        Return only a comma-separated list of keywords."""
        
        response = litellm.completion(
            model="gpt-4o-mini",  # Using OpenAI model through LiteLLM
            messages=[{"role": "user", "content": prompt}],
            temperature=0.7
        )
        
        if (response and hasattr(response, 'choices') and response.choices and 
            hasattr(response.choices[0], 'message') and 
            hasattr(response.choices[0].message, 'content')):
            content = response.choices[0].message.content
            if content:
                additional_keywords = [kw.strip() for kw in content.split(',')]
            else:
                additional_keywords = []
        else:
            additional_keywords = []
        all_keywords = base_keywords + additional_keywords
        
        logger.info(f"Generated {len(all_keywords)} search keywords")
        return all_keywords
        
    except Exception as e:
        logger.error(f"Error generating additional keywords: {str(e)}")
        return base_keywords

def search_financial_users(keywords: List[str]) -> List[Dict]:
    """Search for users posting about financial markets"""
    logger.info(f"Searching for users with {len(keywords)} keywords")
    
    if twitter_client is None:
        # Demo mode - return sample data
        logger.info("Running in demo mode - returning sample data")
        return create_demo_users_data()
    
    # Search tweets by keywords
    all_tweets = twitter_client.search_tweets_by_keywords(keywords, max_results=50)
    
    # Extract unique user IDs
    unique_user_ids = list(set([tweet['author_id'] for tweet in all_tweets]))
    logger.info(f"Found {len(unique_user_ids)} unique users from tweets")
    
    # Get detailed user information
    users_data = twitter_client.get_user_details(unique_user_ids)
    
    return users_data

def create_demo_users_data() -> List[Dict]:
    """Create demo user data when API keys are not available"""
    return [
        {
            'id': '12345',
            'username': 'financepro_demo',
            'followers_count': 15000,
            'verified': True,
            'description': 'Financial markets analyst, sharing daily market insights and trading strategies.'
        },
        {
            'id': '67890',
            'username': 'stocktrader_demo',
            'followers_count': 8500,
            'verified': False,
            'description': 'Day trader focusing on S&P 500 and tech stocks. Risk management is key!'
        },
        {
            'id': '11111',
            'username': 'wallstreet_demo',
            'followers_count': 25000,
            'verified': True,
            'description': 'Wall Street veteran with 15 years experience. Sharing market analysis and economic insights.'
        }
    ]

def filter_qualified_users(users_data: List[Dict]) -> List[TwitterUser]:
    """Filter users based on follower count and tweet frequency criteria"""
    qualified_users = []
    
    for user_data in users_data:
        try:
            # Check follower count criteria
            if user_data['followers_count'] < 5000:
                continue
            
            # Check recent tweet count (last 14 days)
            if twitter_client is None:
                # Demo mode - simulate tweet counts
                recent_tweets_count = 8  # Sample value that meets criteria
            else:
                recent_tweets_count = twitter_client.get_user_recent_tweets_count(user_data['id'])
            
            if recent_tweets_count < 5:
                continue
            
            # Calculate average posts per week
            posts_per_week = float((recent_tweets_count / 14) * 7)
            
            # Create TwitterUser object
            qualified_user = TwitterUser(
                username=user_data['username'],
                user_id=str(user_data['id']),
                followers_count=user_data['followers_count'],
                posts_per_week=round(posts_per_week, 2),
                profile_url=f"https://twitter.com/{user_data['username']}",
                bio=user_data.get('description', ''),
                verified=user_data.get('verified', False),
                recent_tweets_count=recent_tweets_count
            )
            
            qualified_users.append(qualified_user)
            logger.info(f"Qualified user: @{qualified_user.username} ({qualified_user.followers_count} followers)")
            
        except Exception as e:
            logger.error(f"Error processing user {user_data.get('username', 'unknown')}: {str(e)}")
            continue
    
    return qualified_users

# CrewAI Flow Implementation
class FinancialCreatorSearchFlow(Flow):
    """CrewAI Flow for searching and filtering financial market creators"""
    
    def __init__(self):
        super().__init__()
        self.start_time = None
        self.search_keywords = []
        self.total_users_found = 0
        self.qualified_users = []
    
    @start()
    def initiate_search(self):
        """Start the financial creator search process"""
        logger.info("Starting CrowdWisdomTrading AI Agent search process")
        self.start_time = time.time()
        
        return "search_initiated"
    
    @listen(initiate_search)
    def generate_keywords(self, result):
        """Generate search keywords for financial content"""
        logger.info("Generating financial market keywords...")
        
        self.search_keywords = generate_financial_keywords()
        
        return {
            "keywords": self.search_keywords,
            "status": "keywords_generated"
        }
    
    @listen(generate_keywords)
    def search_users(self, result):
        """Search for users based on generated keywords"""
        logger.info("Searching for financial market users...")
        
        keywords = result["keywords"]
        users_data = search_financial_users(keywords)
        self.total_users_found = len(users_data)
        
        return {
            "users_data": users_data,
            "status": "users_found"
        }
    
    @listen(search_users)
    def filter_users(self, result):
        """Filter users based on criteria"""
        logger.info("Filtering users based on criteria...")
        
        users_data = result["users_data"]
        self.qualified_users = filter_qualified_users(users_data)
        
        return {
            "qualified_users": self.qualified_users,
            "status": "users_filtered"
        }
    
    @listen(filter_users)
    def generate_output(self, result):
        """Generate final JSON output with statistics"""
        logger.info("Generating final output...")
        
        end_time = time.time()
        processing_time = round(float(end_time - (self.start_time or 0)), 2)
        
        # Create statistics
        stats = SearchStats(
            total_processing_time=processing_time,
            total_users_found=self.total_users_found,
            total_users_filtered=len(self.qualified_users),
            search_keywords_used=self.search_keywords,
            timestamp=datetime.now().isoformat()
        )
        
        # Create final results
        results = SearchResults(
            qualified_users=self.qualified_users,
            statistics=stats
        )
        
        # Save to JSON file
        output_filename = f"financial_creators_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        
        with open(output_filename, 'w') as f:
            json.dump(results.model_dump(), f, indent=2, default=str)
        
        logger.info(f"Results saved to {output_filename}")
        logger.info(f"Processing completed in {processing_time} seconds")
        logger.info(f"Found {len(self.qualified_users)} qualified creators out of {self.total_users_found} total users")
        
        return {
            "results": results,
            "output_file": output_filename,
            "status": "completed"
        }

def main():
    """Main function to run the CrowdWisdomTrading AI Agent"""
    try:
        # Initialize and run the CrewAI Flow
        flow = FinancialCreatorSearchFlow()
        result = flow.kickoff()
        
        print("\n" + "="*50)
        print("CROWDWISDOM TRADING AI AGENT - RESULTS")
        print("="*50)
        print(f"Processing completed successfully!")
        if hasattr(result, 'output_file'):
            print(f"Output saved to: {result.output_file}")
        if hasattr(result, 'results') and hasattr(result.results, 'qualified_users'):
            print(f"Qualified creators found: {len(result.results.qualified_users)}")
        print("="*50 + "\n")
        
        return result
        
    except Exception as e:
        logger.error(f"Error running CrowdWisdomTrading AI Agent: {str(e)}")
        raise

if __name__ == "__main__":
    main()