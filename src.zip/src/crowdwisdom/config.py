"""
Configuration settings for CrowdWisdomTrading AI Agent
"""

import os
from typing import List

class Config:
    """Configuration class for the application"""
    
    # API Keys
    OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
    TWITTER_BEARER_TOKEN = os.getenv("TWITTER_BEARER_TOKEN")
    
    # Search Configuration
    MIN_FOLLOWERS = 5000
    MIN_TWEETS_LAST_14_DAYS = 5
    MAX_RESULTS_PER_KEYWORD = 50
    SEARCH_DAYS_BACK = 14
    
    # LiteLLM Configuration
    DEFAULT_MODEL = "gpt-4o-mini"  # Using OpenAI model through LiteLLM
    TEMPERATURE = 0.7
    
    # Rate Limiting
    TWITTER_RATE_LIMIT_DELAY = 1  # seconds between requests
    
    # Output Configuration
    OUTPUT_FORMAT = "json"
    LOG_LEVEL = "INFO"
    
    # Financial Keywords (base set)
    BASE_FINANCIAL_KEYWORDS = [
        "US stock market", "S&P 500", "NASDAQ", "Dow Jones", "NYSE",
        "Federal Reserve", "Fed rate", "interest rates", "bond yields",
        "Wall Street", "stock picks", "market analysis", "earnings report",
        "economic indicators", "inflation data", "GDP growth", "unemployment rate",
        "tech stocks", "banking sector", "energy sector", "healthcare stocks",
        "market volatility", "bull market", "bear market", "market crash",
        "IPO", "stock split", "dividend yield", "P/E ratio", "market cap"
    ]
    
    @classmethod
    def validate_api_keys(cls) -> List[str]:
        """Validate that required API keys are present"""
        missing_keys = []
        
        if not cls.OPENAI_API_KEY:
            missing_keys.append("OPENAI_API_KEY")
        
        if not cls.TWITTER_BEARER_TOKEN:
            missing_keys.append("TWITTER_BEARER_TOKEN")
        
        return missing_keys
    
    @classmethod
    def is_demo_mode(cls) -> bool:
        """Check if we should run in demo mode (without real API calls)"""
        return bool(cls.validate_api_keys())